<div class="content-header row">
    <div class="content-header-left col-md-6 col-12 mb-2">
        <h3 class="content-header-title ml-1">Master</h3>
    </div>
</div>
<div class="content-body">
    <!-- Description -->
    <section id="description" class="card">
        <div class="card-header">
            <h4 class="card-title">SELAMAT DATANG</h4><br>
            <h5><strong><?= $user['nama_akun']; ?></strong></h5>
        </div>
        <div class="card-content">
            <div class="card-body">
                <div class="card-text">
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eius odit sunt odio ratione, ullam ipsum explicabo iusto veniam, similique commodi neque tempora sint et ad. Ipsum non dignissimos veritatis rerum.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <!--/ Description -->
</div>